package com.example.myfinance

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// ----- Data models -----

data class Hucha(val nombre: String, val saldoActual: Double, val meta: Double)
data class Movimiento(val descripcion: String, val monto: Double, val fecha: String)

// ----- PantallaInicio -----

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaInicio() {
    // Datos de ejemplo
    val saldoTotal = 1500.0 // Ejemplo: ingresos - gastos del mes actual
    val huchas = listOf(
        Hucha("Hucha Viaje", 500.0, 1000.0),
        Hucha("Fondo Emergencia", 300.0, 500.0),
        Hucha("Meta de Compra", 200.0, 800.0)
    )
    val movimientosRecientes = listOf(
        Movimiento("Compra supermercado", -50.0, "01/03/2025"),
        Movimiento("Ingreso sueldo", 1000.0, "28/02/2025"),
        Movimiento("Pago servicios", -120.0, "27/02/2025"),
        Movimiento("Transferencia a hucha", -200.0, "26/02/2025"),
        Movimiento("Compra online", -80.0, "25/02/2025")
    )
    val filtroPeriodo = "Mes Actual" // Por defecto

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dashboard Financiero") },
                actions = {
                    // Aquí puedes implementar un DropdownMenu o similar para los filtros.
                    DropdownMenuFiltro(selectedFiltro = filtroPeriodo)
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { /* Acción: Añadir transacción rápidamente */ }
            ) {
                Icon(Icons.Default.Add, contentDescription = "Añadir Transacción")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Resumen financiero
            Text(
                text = "Saldo Total: $${saldoTotal}",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Tarjetas de huchas en un carrusel horizontal
            Text(
                text = "Mis Huchas",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(huchas) { hucha ->
                    HuchaCard(hucha = hucha)
                }
                // Tarjeta para acción rápida: Añadir nueva hucha o transferir
                item {
                    Card(
                        modifier = Modifier
                            .width(150.dp)
                            .height(150.dp)
                            .clickable { /* Acción: Añadir hucha/transferencia */ },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Añadir Hucha")
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Añadir Hucha")
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Movimientos recientes
            Text(
                text = "Movimientos Recientes",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(movimientosRecientes) { movimiento ->
                    MovimientoItem(movimiento = movimiento)
                }
            }
        }
    }
}

// ----- Composables auxiliares -----

@Composable
fun HuchaCard(hucha: Hucha) {
    Card(
        modifier = Modifier
            .width(150.dp)
            .height(150.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = hucha.nombre, style = MaterialTheme.typography.titleSmall)
            // Cálculo del progreso (valor entre 0 y 1)
            val progreso = (hucha.saldoActual / hucha.meta).coerceIn(0.0, 1.0)
            LinearProgressIndicator(
                progress = { progreso.toFloat() },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(text = "Saldo: $${hucha.saldoActual}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun MovimientoItem(movimiento: Movimiento) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = movimiento.descripcion, style = MaterialTheme.typography.bodyMedium)
            Text(text = "${movimiento.monto} €", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun DropdownMenuFiltro(selectedFiltro: String) {
    // Ejemplo simple: por ahora solo mostramos el filtro seleccionado.
    // Puedes expandirlo para que al pulsar se despliegue un menú con otras opciones.
    Text(text = selectedFiltro, modifier = Modifier.padding(end = 16.dp))
}
