package com.example.myfinance

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PantallaPerfil() {
    Text(text = "Perfil de Usuario")
}