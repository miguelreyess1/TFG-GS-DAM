package com.example.myfinance

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PantallaCalculadora() {
    Text(text = "Calculadora de Interés Compuesto")
}
