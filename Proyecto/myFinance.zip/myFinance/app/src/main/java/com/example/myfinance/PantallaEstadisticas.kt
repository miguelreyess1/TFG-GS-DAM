package com.example.myfinance

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PantallaEstadisticas() {
    Text(text = "Estadísticas Financieras")
}