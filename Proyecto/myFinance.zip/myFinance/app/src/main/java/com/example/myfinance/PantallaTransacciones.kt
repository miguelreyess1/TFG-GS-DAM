package com.example.myfinance

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun PantallaTransacciones() {
    Text(text = "Gestión de Transacciones")
}
