import React from 'react';
import './Contacto.css';

export default function Contacto() {
  return (
    <div className="home-container">
      <h2>Estás en Contacto</h2>
    </div>
  );
}
