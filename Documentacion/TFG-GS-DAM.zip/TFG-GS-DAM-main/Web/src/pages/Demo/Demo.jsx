import React from 'react';
import './Demo.css';

export default function Demo() {
  return (
    <div className="home-container">
      <h2>Estás en Demo</h2>
    </div>
  );
}
