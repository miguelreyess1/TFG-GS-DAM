import React from 'react';
import './Caracteristicas.css';

export default function Caracteristicas() {
  return (
    <div className="home-container">
      <h2>Estás en Caracteristicas</h2>
    </div>
  );
}
