import React from 'react';
import './Descarga.css';

export default function Descarga() {
  return (
    <div className="home-container">
      <h2>Estás en Descarga</h2>
    </div>
  );
}
