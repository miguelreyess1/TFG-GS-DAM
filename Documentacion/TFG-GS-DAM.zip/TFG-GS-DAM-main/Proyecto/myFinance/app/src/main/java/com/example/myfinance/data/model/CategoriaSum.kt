package com.example.myfinance.data.model

data class CategorySum(
    val nombre: String,
    val monto: Float
)
